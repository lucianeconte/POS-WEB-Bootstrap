<div class="container">
	<h1 class="text-center">Erro 404</h1>
	<p class="text-center">
		<strong>A página que vc está tentando acessar não existe ou foi removida</strong>
	</p>
	<p class="text-center">
		<a href="javascript:history.back()" class="btn btn-success">
			Voltar à página anterior
		</a>
	</p>

</div>